package com.qsavvy.stepDefs;


import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.openqa.selenium.WebDriver;

import static com.saucelabdemo.utilities.GenericUtilities.readPropertyFileData;

public class QSavvyHooksStepDefs {

    public WebDriver driver;
    public static RequestSpecification requestSpec;
    public static ResponseSpecification responseSpec;

    @Before
    public void beforeScenario(Scenario scenario) {
        System.out.println(scenario.getName());
        System.out.println(scenario.getSourceTagNames());
        System.out.println("This will run before the Scenario");
    }

    @After
    public void afterScenario() {
        System.out.println("This will run after the Scenario");
    }

    @Before(value = "@API")
    public void setBaseURI() {
        requestSpec = new RequestSpecBuilder().
                setBaseUri(readPropertyFileData("QA_sauceLab","Base_URI")).
                build();
        responseSpec = new ResponseSpecBuilder().expectStatusCode(200).build();
    }


}
