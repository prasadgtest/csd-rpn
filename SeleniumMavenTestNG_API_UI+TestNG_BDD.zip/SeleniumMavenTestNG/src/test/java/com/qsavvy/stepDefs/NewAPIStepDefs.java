package com.qsavvy.stepDefs;

import com.github.javafaker.Faker;
import com.saucelabdemo.pojoClasses.responses.BookingIDResponse;
import com.saucelabdemo.utilities.GenericUtilities;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.restassured.response.Response;
import org.json.simple.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;
import java.util.Map;

import static com.qsavvy.stepDefs.QSavvyHooksStepDefs.requestSpec;
import static com.saucelabdemo.utilities.GenericUtilities.readPropertyFileData;
import static io.restassured.RestAssured.given;

public class NewAPIStepDefs {

    private static final Logger logger = LoggerFactory.getLogger(NewAPIStepDefs.class);
    @Given("i post new book registration api on heroku app")
    public void iPostNewBookRegistrationApiOnHerokuApp(DataTable table) {
        GenericUtilities utilities = new GenericUtilities();
        logger.info("New Book Registration");
        List<Map<String, String>> listMap = table.asMaps(String.class, String.class);
        boolean tcResult = false;

        Faker faker = new Faker();

        JSONObject rootObject = new JSONObject();
        rootObject.put("firstname", listMap.get(0).get("firstname"));
        rootObject.put("lastname", faker.name().lastName());
        rootObject.put("totalprice", faker.number().digits(3));
        rootObject.put("depositpaid", faker.bool().bool());
        rootObject.put("additionalneeds", faker.food().fruit());

        JSONObject bookingDates = new JSONObject();
        bookingDates.put("checkin", utilities.readPropertyFileData("QA_sauceLab", "checkin"));
        bookingDates.put("checkout", utilities.readPropertyFileData("QA_sauceLab","checkout"));

        rootObject.put("bookingdates", bookingDates);


        Response response = given().
                spec(requestSpec).
                contentType("application/json").
                body(rootObject.toJSONString()).log().body().
                when().
                post("/booking");

        //Storing the response in a POJO and retrieving the data
        BookingIDResponse bookingIdResponse = response.as(BookingIDResponse.class);
        System.out.println("BookingID: "+bookingIdResponse.getBookingid());
        System.out.println("Checkin Date: "+bookingIdResponse.getBookingDetailsResponse().getBookingDatesResponse().getCheckin());

    }
}
