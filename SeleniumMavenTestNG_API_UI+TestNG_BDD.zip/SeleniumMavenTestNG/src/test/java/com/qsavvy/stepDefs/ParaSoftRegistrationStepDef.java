package com.qsavvy.stepDefs;


import com.saucelabdemo.pages.ParasoftRegistrationPage;
import com.saucelabdemo.pages.SauceLoginPage;
import com.saucelabdemo.utilities.GenericUtilities;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static org.testng.Assert.assertEquals;

public class ParaSoftRegistrationStepDef {

    public WebDriver driver;
    public ParasoftRegistrationPage parasoftRegistrationPage;
    public SauceLoginPage sauceLoginPage;
    private static final Logger logger = LoggerFactory.getLogger(ParaSoftRegistrationStepDef.class);

    @Given("i open the parasoft application")
    public void openParaSoftApplication() {
        try {
            logger.info("Opening the browser and navigating to Parasoft Application");
            ChromeOptions options = new ChromeOptions();
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver(options);
            Thread.sleep(2000);
            driver.manage().window().maximize();
            GenericUtilities utils = new GenericUtilities();
            String url = utils.readPropertyFileData("QA_sauceLab", "parasoftAppUrl");
//            driver.get("https://parabank.parasoft.com/parabank/index.htm");
            driver.get(url);
            Thread.sleep(1000);
        } catch (InterruptedException e){}
    }

    @When("i say hello {string}")
    public void helloDisplay(String value) {
        System.out.println("Say Hello "+value);
    }

    @When("i register a new user with following data")
    public void registerUserStep(DataTable table) {
        logger.info("Registeration of a new user");
        List<Map<String, String>> listMap = table.asMaps(String.class, String.class);
        boolean tcResult = false;
        parasoftRegistrationPage = new ParasoftRegistrationPage(driver);

        tcResult = parasoftRegistrationPage.registerUser(listMap.get(0).get("FirstName"), listMap.get(0).get("LastName"),
                listMap.get(0).get("Address"), listMap.get(0).get("City"), listMap.get(0).get("State"),
                listMap.get(0).get("ZipCode"), listMap.get(0).get("Phone"), listMap.get(0).get("SSN"),
                listMap.get(0).get("UserName"), listMap.get(0).get("Password"), listMap.get(0).get("ConfirmPassword"));
        assertEquals(true, tcResult);
    }

    @When("i login with newly created credentials with username as {string} and password as {string}")
    public void loginWithNewCredentials(String userName, String password) throws IOException {
        sauceLoginPage = new SauceLoginPage(driver);
        boolean tcResult = false;
        tcResult = sauceLoginPage.loginSauceLabs(userName, password);
        assertEquals(true, tcResult);
    }

    @After(value = "@Web")
    public void tearDown() {
        logger.info("Closing all browser sessions");
        driver.close();
        driver.quit();
    }

}