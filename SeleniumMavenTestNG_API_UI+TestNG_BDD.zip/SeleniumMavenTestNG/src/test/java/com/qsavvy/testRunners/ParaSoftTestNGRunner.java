package com.qsavvy.testRunners;


import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;

@CucumberOptions(
        features = "classpath:features",
        glue = "classpath:com.qsavvy.stepDefs",
        tags = "@API",
        plugin = {"pretty", "html:target/cucumber.html", "json:target/cucumber.json"})
public class ParaSoftTestNGRunner extends AbstractTestNGCucumberTests {

}


