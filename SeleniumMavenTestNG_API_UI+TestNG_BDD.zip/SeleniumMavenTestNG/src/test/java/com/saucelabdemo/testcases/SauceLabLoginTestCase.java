package com.saucelabdemo.testcases;

import com.saucelabdemo.pages.ParasoftRegistrationPage;
import com.saucelabdemo.pages.SauceLoginPage;
import com.saucelabdemo.utilities.GenericUtilities;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.*;

import java.io.IOException;
import java.time.Duration;


public class SauceLabLoginTestCase {

    WebDriver driver;
    GenericUtilities genericUtil;


    SauceLoginPage sauceLoginPage;
    ParasoftRegistrationPage parasoftRegistrationPage;
//    FlightFinderPage flightFinderPage;
//    SelectFlightPage selectFlightPage;
//    BookFlightPage bookFlightPage;
//    FlightConfirmationPage flightConfirmationPage;

    // Test Case
//    @Test(dataProvider = "newTourData")
//    public void bookFlight(String uname, String pwd, String departFrom, String departDate, String fname, String lname,
//                           String ccNum) {
//        homePage.loginUser(uname, pwd);
//        flightFinderPage.findFlights(departFrom, departDate);
//        selectFlightPage.reserveFlight();
//        bookFlightPage.bookFlight(fname, lname, ccNum);
//        flightConfirmationPage.clickLogOut();
//    }

    @Test(enabled = false, dataProvider = "loginData")
    public void loginToSauceLabApplication(String slLoginUsername, String slLoginPassword, boolean expectedResult) throws IOException, InterruptedException {
        boolean loginPassedOrFailed = false;
        genericUtil = new GenericUtilities();
//        String slLoginUsername = genericUtil.readPropertyFileData("usernameData");
//        String slLoginPassword = genericUtil.readPropertyFileData("passwordData");
        loginPassedOrFailed = sauceLoginPage.loginSauceLabs(slLoginUsername, slLoginPassword);
//        Assert.assertTrue(loginPassedOrFailed, "Logged in Successfully");
        Assert.assertEquals(loginPassedOrFailed, expectedResult);
        Thread.sleep(2000);
    }

    @Test(dataProvider = "newRegisterParaSoft")
    public void registerNewUser(String strfirstName, String strlastName, String straddressStreet, String strcity, String strstate, String strzipCode, String strphone, String strssn, String struserName, String strpassword, String strconfirmPassword) {
        boolean testCaseResult = false;
        testCaseResult = parasoftRegistrationPage.registerUser(strfirstName, strlastName, straddressStreet, strcity, strstate, strzipCode, strphone, strssn, struserName, strpassword, strconfirmPassword);
        Assert.assertEquals(true, testCaseResult, "New User on ParaSoft got registered Successfully");
    }

    @BeforeMethod
    public void beforeMethod() throws IOException {
        // Initialize driver
        try {
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
            Thread.sleep(2000);
            driver.manage().window().maximize();
            driver.get("https://parabank.parasoft.com/parabank/index.htm");
            Thread.sleep(1000);
        } catch (InterruptedException e){}
        genericUtil = new GenericUtilities();
        // Page Factory Initialization for all page objects
        sauceLoginPage = PageFactory.initElements(driver, SauceLoginPage.class);
        parasoftRegistrationPage = PageFactory.initElements(driver, ParasoftRegistrationPage.class);

        // Navigate to URL
//        driver.get(genericUtil.readPropertyFileData("appURL"));
//		driver.get("http://newtours.demoaut.com");

    }

    // Driver closure
    @AfterMethod
    public void afterMethod() {
        // Close and quit the driver to close the Browser
        driver.close();
        driver.quit();
    }

    // Create test data
    @DataProvider
    public Object[][] newTourData() throws IOException {
        //driver.get(GenericUtilities.readPropertyFileData1("appURL1"));
        return new Object[][]{{"demo", "demo", "London", "7", "john", "Doe", "56465465"}};
        //	return null;
    }

    @DataProvider
    public Object[][] newRegisterParaSoft() throws IOException {
        //driver.get(GenericUtilities.readPropertyFileData1("appURL1"));
        return new Object[][]{{"testheapstack3", "training3", "#221, Chandra Layout", "Bengaluru", "Karantaka", "560040", "9874622547", "8855221144", "testheapstack3", "training@123", "training@123"},
                {"testheapstack2", "training2", "#221, Chandra Layout", "Bengaluru", "Karantaka", "560040", "9874622547", "8855221144", "testheapstack2", "training@123", "training@123"}};
        //	return null;
    }

    // Setting System property
    @BeforeTest
    public void beforeTest() {
        // Set System Property
        System.setProperty("webdriver.chrome.driver", "src/main/resources/drivers/chromedriver.exe");
    }

    @DataProvider
    public Object[][] loginData() throws IOException {
        genericUtil = new GenericUtilities();
        return new Object[][]{{genericUtil.readPropertyFileData("usernameData"), genericUtil.readPropertyFileData("passwordData"), true}
                , {genericUtil.readPropertyFileData("invalidusernameData"), genericUtil.readPropertyFileData("passwordData"), false}
                , {genericUtil.readPropertyFileData("usernameData"), genericUtil.readPropertyFileData("invalidpasswordData"), false}
                , {genericUtil.readPropertyFileData("invalidusernameData"), genericUtil.readPropertyFileData("invalidpasswordData"), false}
                , {genericUtil.readPropertyFileData("invalidusernameData"), genericUtil.readPropertyFileData("blankPasswordData"), false}};
    }

}