package com.saucelabdemo.utilities;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

public class GetHREmails {
    public static void main(String[] args) {
//        System.setProperty("webdriver.chrome.driver", "src/main/resources/drivers/chromedriver.exe");
        WebDriver driver;
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.get("https://salesleadsforever.com/free-list-of-companies-with-hr-email-details-of-indian-companies-2023/");
        WebElement table = driver.findElement(By.xpath("//*[@id=\"tablepress-19\"]/tbody"));
        List<WebElement> allTRs = driver.findElements(By.xpath("//*[@id=\"tablepress-19\"]/tbody/tr"));
        System.out.println(allTRs.size());
        for(int i = 0; i <allTRs.size(); i++) {
            String emailIDTR = "//*[@id=\"tablepress-19\"]/tbody/tr[?]/td[1]/a";
            emailIDTR = emailIDTR.replaceAll("\\?", String.valueOf(i+1));
            System.out.println(driver.findElement(By.xpath(emailIDTR)).getAttribute("href") + " === "+driver.findElement(By.xpath(emailIDTR)).getText());
        }
    }
}
