package com.saucelabdemo.utilities;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class BaseTest {





    /*****************************************************************************************************************/
//	@AfterSuite
    public void afterSuite() {

    }

    /****************************************************************************************************************/
//	@BeforeClass
    public void beforeClass() {
    }

    /****************************************************************************************************************/
//	@AfterClass
    public void afterClass(){

    }

    /************************************************************************************************************************/
//    @BeforeMethod
//    public void beforeMethod() {
//
//    }

    //	@AfterMethod
    public void afterMethod() {

    }

}
/*****************************************************************************************************************/