package com.saucelabdemo.utilities;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class GenericUtilities {
    public String readPropertyFileData(String keyName) {
        String retValue = null;
        try {
            Properties prop = null;
//            FileReader reader = new FileReader(System.getProperty("user.dir") + "\\src\\com\\selenium\\testData\\BookFlight.properties");
            FileReader reader = new FileReader("testData/QA_sauceLab.properties");
            prop = new Properties();
            prop.load(reader);
            retValue = prop.getProperty(keyName).toString();
        }  catch(IOException e) {
            System.out.println("Exception thrown");
        }
        return retValue;
    }

    public static String readPropertyFileData(String fileName, String keyName) {
        String retValue = null;
        try {
            Properties prop = null;
            String envName = "";
//            FileReader reader = new FileReader(System.getProperty("user.dir") + "\\src\\com\\selenium\\testData\\BookFlight.properties");
//            fileName = envName + "_sauceLab";
            FileReader reader = new FileReader("testData/"+fileName+".properties");

            prop = new Properties();
            prop.load(reader);
            retValue = prop.getProperty(keyName).toString();
        }  catch(IOException e) {
            System.out.println("Exception thrown");
        }
        return retValue;
    }

    public static String readPropertyFileData1(String KeyName1) throws IOException {
        String retValue1 = null;
        try {
            Properties prop1 = null;

            FileReader reader1 = new FileReader(System.getProperty("user.dir") + "\\src\\com\\selenium\\testData\\BookFlight.properties");
            prop1 = new Properties();
            prop1.get(reader1);
            retValue1 = prop1.getProperty(KeyName1).toString();
        }  catch(IOException e) {
            System.out.println("Exception thrown");
        }
        return retValue1;
    }

}
