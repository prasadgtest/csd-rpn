package com.saucelabdemo.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.io.IOException;

public class SauceLoginPage extends BasePage{

    public WebDriver driver;
    public SauceLoginPage sauceLoginPage;


//    @FindBy(id ="user-name")
//    private WebElement usernameEdit;
    private final By usernameEdit = By.name("username");
    public WebElement getUsernameEdit() {return getWebElement(usernameEdit);}

//    @FindBy(id ="password")
//    private WebElement passwordEdit;
    private final By passwordEdit = By.name("password");
    public WebElement getPasswordEdit() {return getWebElement(passwordEdit);}

//    @FindBy(id = "login-button")
//    private WebElement loginBtn;
    private final By loginBtn = By.xpath("//*[@id=\"loginPanel\"]/form/div[3]/input");
    public WebElement getloginBtn() {return getWebElement(loginBtn);}

    private final By logOutLink = By.xpath("//a[text()='Log Out']");
    public WebElement getLogOutLink() {return getWebElement(logOutLink);}

    @FindBy(css = "#header_container > div.primary_header > div.header_label > div")
    private WebElement swagLabsLogo;

    @FindBy(css = "#login_button_container > div > form > div.error-message-container.error > h3")
    private WebElement loginErrorMessage;

    public SauceLoginPage(WebDriver driver) {
        super(driver);
        this.driver = driver;
    }

    public boolean loginSauceLabs(String username, String pwd) throws IOException {
        boolean flag1 = false;
        waitForPageLoad();
        enterText(getUsernameEdit(), username);
//        usernameEdit.sendKeys(username);
        enterText(getPasswordEdit(), pwd);
//        passwordEdit.sendKeys(pwd);
        clickOn(getloginBtn());
//        loginBtn.click();
        waitForPageLoad();
//        flag1 = idElemDisplayed(swagLabsLogo);
//        if(swagLabsLogo.isDisplayed()) {
//            flag = true;
//        }
        if(isElemDisplayed(getLogOutLink())) {
            flag1 = true;
        }
        return flag1;
    }

}
