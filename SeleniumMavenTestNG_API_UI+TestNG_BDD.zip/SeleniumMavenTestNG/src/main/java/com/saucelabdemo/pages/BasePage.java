package com.saucelabdemo.pages;

import com.saucelabdemo.utilities.GenericUtilities;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.IOException;
import java.time.Duration;

public class BasePage {

    public WebDriver driver;
    public GenericUtilities genericUtilities;

    public BasePage(WebDriver driver) {
        this.driver = driver;
        genericUtilities = new GenericUtilities();
    }

    public void enterText(WebElement element, String dataToEnter) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.valueOf(genericUtilities.readPropertyFileData("timeout"))));
        wait.until(ExpectedConditions.visibilityOf(element));
        element.sendKeys(dataToEnter);
    }

    public void clickOn(WebElement element) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.valueOf(genericUtilities.readPropertyFileData("timeout"))));
        wait.until(ExpectedConditions.elementToBeClickable(element));
        element.click();
    }

    public boolean isElemDisplayed(WebElement element) {
        boolean flag = false;
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.valueOf(genericUtilities.readPropertyFileData("timeout"))));
            wait.until(ExpectedConditions.visibilityOf(element));
            if (element.isDisplayed()) {
                flag = true;
            }
        } catch (TimeoutException e) {
            System.out.println("Element is NOT Displayed");
        }
        return flag;
    }

    public void waitForPageLoad() {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e){}
    }

    public WebElement getWebElement(By locator) {
        WebElement element = null;
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(Integer.valueOf(genericUtilities.readPropertyFileData("timeout"))));
        wait.until(ExpectedConditions.elementToBeClickable(locator));
        try {
            element = driver.findElement(locator);
        }catch (StaleElementReferenceException e) {
            element = driver.findElement(locator);
        }
        return  element;
    }
}
