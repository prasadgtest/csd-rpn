package com.saucelabdemo.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParasoftRegistrationPage extends BasePage {
    public WebDriver driver;
    ParasoftRegistrationPage parasoftRegistrationPage;
    private static final Logger logger = LoggerFactory.getLogger(ParasoftRegistrationPage.class);
    public ParasoftRegistrationPage(WebDriver driver) {
        super(driver);
//        this.driver = driver;
//        PageFactory.initElements(driver, ParasoftRegistrationPage.class);
    }

//    @FindBy(xpath = "//a[text()='Register']")
//    WebElement registerLink;
    private final By registerLink = By.xpath("//a[text()='Register']");
    public WebElement getRegisterLink() {
        return getWebElement(registerLink);
    }
//    @FindBy(id="customer.firstName")
//    WebElement firstName;
    private final By firstName = By.id("customer.firstName");
    public WebElement getFirstName() {return getWebElement(firstName);}

//    @FindBy(id = "customer.lastName")
//    WebElement lastName;
    private final By lastName = By.id("customer.lastName");
    public WebElement getLastName() {return getWebElement(lastName);}

//    @FindBy(id = "customer.address.street")
//    WebElement addressStreet;
    private final By addressStreet = By.id("customer.address.street");
    public WebElement getAddressStreet() {return getWebElement(addressStreet);}

//    @FindBy(id = "customer.address.city")
//    WebElement city;
    private final By city = By.id("customer.address.city");
    public WebElement getCity() {return getWebElement(city);}

//    @FindBy(id = "customer.address.state")
//    WebElement state;
    private final By state = By.id("customer.address.state");
    public WebElement getState() {return getWebElement(state);}

//    @FindBy(id = "customer.address.zipCode")
//    public WebElement zipCode;
    private final By zipCode = By.id("customer.address.zipCode");
    public WebElement getZipCode() {return getWebElement(zipCode);}

//    @FindBy(id = "customer.phoneNumber")
//    public WebElement phone;
    private final By phone = By.id("customer.phoneNumber");
    public WebElement getPhone() {return getWebElement(phone);}

//    @FindBy(id = "customer.ssn")
//    private WebElement ssn;
    private final By ssn = By.id("customer.ssn");
    public WebElement getSsn() {return getWebElement(ssn);}

//    @FindBy(id = "customer.username")
//    private WebElement userName;
    private final By userName = By.id("customer.username");
    public WebElement getUserName() {return getWebElement(userName);}

//    @FindBy(id = "customer.password")
//    private WebElement password;
    private final By password = By.id("customer.password");
    public WebElement getPassword() {return getWebElement(password);}

//    @FindBy(id = "repeatedPassword")
//    private WebElement confirmPassword;
    private final By confirmPassword = By.id("repeatedPassword");
    public WebElement getConfirmPassword() {return getWebElement(confirmPassword);}

//    @FindBy(xpath = "//input[@value='Register']")
//    private WebElement registerButton;
    private final By registerButton = By.xpath("//input[@value='Register']");
    public WebElement getRegisterButton() {return getWebElement(registerButton);}

//    @FindBy(xpath = "//*[@id='rightPanel']/h1")
//    public WebElement successfullRegisteredUserWelcomeMsg;
    private final By successfullRegisteredUserWelcomeMsg = By.xpath("//*[@id='rightPanel']/h1");
    public WebElement getSuccessfullRegisteredUserWelcomeMsg() {return getWebElement(successfullRegisteredUserWelcomeMsg);}

//    @FindBy(xpath = "//*[@id=\"rightPanel\"]/p")
//    public WebElement successfulCreatedUserMsg;
    private final By successfulCreatedUserMsg = By.xpath("//*[@id='rightPanel']/p");
    public WebElement getSuccessfulCreatedUserMsg() {return getWebElement(successfulCreatedUserMsg);}

//    @FindBy(xpath = "//a[text()='Log Out']")
//    public WebElement logOutLink;
    private final By logOutLink = By.xpath("//a[text()='Log Out']");
    public WebElement getLogOutLink() {return getWebElement(logOutLink);}


    public boolean registerUser(String strfirstName, String strlastName, String straddressStreet, String strcity, String strstate, String strzipCode, String strphone, String strssn, String struserName, String strpassword, String strconfirmPassword) {
        logger.info("Entering the details for User Registration Page");
        boolean isUserRegisteredSuccessfully = false;
        waitForPageLoad();
        clickOn(getRegisterLink());
        waitForPageLoad();
        enterText(getFirstName(), strfirstName);
        enterText(getLastName(), strlastName);
        enterText(getAddressStreet(), straddressStreet);
        enterText(getCity(), strcity);
        enterText(getState(), strstate);
        enterText(getZipCode(), strzipCode);
        enterText(getPhone(), strphone);
        enterText(getSsn(),strssn);
        enterText(getUserName(),struserName);
        enterText(getPassword(),strpassword);
        enterText(getConfirmPassword(), strconfirmPassword);
//        registerButton.click();
        clickOn(getRegisterButton());
        waitForPageLoad();
        if(getSuccessfulCreatedUserMsg().getText().equalsIgnoreCase("Your account was created successfully. You are now logged in.")) {
            isUserRegisteredSuccessfully = true;
            try {
                if (isElemDisplayed(getLogOutLink())) {
                    clickOn(getLogOutLink());
                }
            }catch (NoSuchElementException e) {}
        }
        return isUserRegisteredSuccessfully;
    }
}
