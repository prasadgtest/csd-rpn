package pojoClasses;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class GetSlideImages {
    public static void main(String[] args) {

        String chapterName = "Chapter-5-Tools";
        String filename = "H:\\ISTQB_Slides\\CTFL_PerformanceTester\\";

        int slideCount = 100;

        for(int i = 1; i <= slideCount; i++) {
            try {
//                https://image.slidesharecdn.com/chapter1-basicconcepts-210803121814/75/Chapter-1-Basic-Concepts-1-2048.jpg
//                https://image.slidesharecdn.com/chapter2-performancemeasurementfundamentals-210803121814/75/Chapter-2-Performance-Measurement-Fundamentals-1-2048.jpg
//                https://image.slidesharecdn.com/chapter3-performancetestinginthesoftwarelifecycle-210803121830/75/Chapter-3-Performance-Testing-in-the-Software-Lifecycle-1-2048.jpg
//                https://image.slidesharecdn.com/chapter4-performancetestingtasks-210803121844/75/Chapter-4-Performance-Testing-Tasks-1-2048.jpg
//                https://image.slidesharecdn.com/chapter5-tools-210803121845/75/Chapter-5-Tools-1-2048.jpg
                String url = "https://image.slidesharecdn.com/chapter5-tools-210803121845/75/"+chapterName+"-???"+"-2048.jpg";
                String targetFileName = filename+chapterName+"_"+"???"+".jpg";
                url = url.replace("???", String.valueOf(i));
                targetFileName = targetFileName.replace("???", String.valueOf(i));
                URL imageUrl = new URL(url);
                HttpURLConnection connection = (HttpURLConnection) imageUrl.openConnection();
                connection.setRequestMethod("GET");

                InputStream inputStream = connection.getInputStream();
                FileOutputStream outputStream = new FileOutputStream(targetFileName);

                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    outputStream.write(buffer, 0, bytesRead);
                }

                outputStream.close();
                inputStream.close();
                connection.disconnect();
            } catch (Exception e) {
                break;
            }
        }
    }
}
