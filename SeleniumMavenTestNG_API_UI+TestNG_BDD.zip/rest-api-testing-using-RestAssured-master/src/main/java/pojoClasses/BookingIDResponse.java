package pojoClasses;

import com.fasterxml.jackson.annotation.JsonProperty;

public class BookingIDResponse {
    @JsonProperty("bookingid")
    private Integer bookingid;
    @JsonProperty("booking")
    private BookingDetailsResponse bookingDetailsResponse;


    @JsonProperty("bookingid")
    public Integer getBookingid() {
        return bookingid;
    }

    @JsonProperty("bookingid")
    public void setBookingid(Integer bookingid) {
        this.bookingid = bookingid;
    }

    @JsonProperty("bookingDetailsResponse")
    public BookingDetailsResponse getBookingDetailsResponse() {
        return bookingDetailsResponse;
    }

    @JsonProperty("bookingDetailsResponse")
    public void setBooking(BookingDetailsResponse bookingDetailsResponse) {
        this.bookingDetailsResponse = bookingDetailsResponse;
    }

}
