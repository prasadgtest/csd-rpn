package utility;


import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DBQueries {
    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/automationtesting", "root", "root");
            Statement statement = con.createStatement();
            System.out.println("Connection established Successfully!");

            //////////////////////////////// INSERT COMMAND ////////////////////////////////////
            String insertQuery = "INSERT INTO automationtesting.automationtools (idautomationTools, automationToolName, supportedTech, belongsTo, openSource) VALUES (3, 'Appium', 'Mobile', 'io.Appium', True);";
            executeUpdateQuery(con, insertQuery);

            //////////////////////////////// INSERT COMMAND ////////////////////////////////////
            String insertQueryWithPreparedStatement = "INSERT INTO automationtesting.automationtools (idautomationTools, automationToolName, supportedTech, belongsTo, openSource) VALUES (?, ?, ?, ?, ?);";
            insertWithPreparedStatement(con, insertQueryWithPreparedStatement);


            /////////////READ/SELECT SINGLE/MULTIPLE ROW OUTPUT QUERY AND DISPLAY THE DATA///////////////
            String selectQueryWithSingleRowForDisplay = "select * from automationtools where automationToolName = 'RestAssured' limit 1;";
            readData(con, selectQueryWithSingleRowForDisplay);

            ////////////READ/SELECT SINGLE ROW OUTPUT QUERY AND STORE THE RESULT IN MAP ////////////////////////
            String selectQueryWithSingleRows = "select * from automationtools where automationToolName = 'RestAssured' limit 1;";
            ResultSet readResutltSet1 = readDataWithPreparedStatement(con, selectQueryWithSingleRows);
            Map<String, String> outputWithSingleRows = getMapFromResultSet(readResutltSet1);

            ////////////READ/SELECT MULTIPLE ROW OUTPUT QUERY AND STORE THE RESULT IN MAP ////////////////////////
            String selectQueryWithManyRows = "select * from automationtools";
            ResultSet readResutltSet2 = readDataWithPreparedStatement(con, selectQueryWithManyRows);
            List<Map<String, String>> outputWithManyRows = getListOfMapFromResultSet(readResutltSet2);

            //////////////////////////////////UPDATE QUERY//////////////////////////////////
            String updateQuery = "UPDATE automationtesting.automationtools SET openSource = '0' WHERE idautomationTools = 2;";
            executeUpdateQuery(con,updateQuery);

            //////////////////////////////////DELETE QUERY//////////////////////////////////
            String deleteQuery = "DELETE FROM automationtesting.automationtools where automationToolName = 'Appium';";
            executeDeleteQuery(con,deleteQuery);


            //////////////CLOSE THE RESULTSETS, STATEMENTS AND CONNECTIONS//////////////////
            readResutltSet1.close();
            readResutltSet2.close();
            statement.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }


    public static void insertWithPreparedStatement(Connection con, String query) {
        try {
            // Adding 1st Record
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, 4);
            ps.setString(2, "Tosca");
            ps.setString(3, "All");
            ps.setString(4, "Tricentis");
            ps.setBoolean(5, false);

            ps.addBatch();

            ps.executeBatch();

            System.out.println("Inserted Multiple Records Successfully!");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void readData(Connection con, String query) {
        try {
            if (con != null) {
                Statement statement = con.createStatement();

                // execute the query and get the result set
                ResultSet resultSet = statement.executeQuery(query);

                // iterate through the result set and print the data
                while (resultSet.next()) {
                    int id = resultSet.getInt("idautomationTools");
                    String toolName = resultSet.getString("automationToolName");
                    String supportedTech = resultSet.getString("supportedTech");
                    String toolOwner = resultSet.getString("belongsTo");
                    boolean isOpenSource = resultSet.getBoolean("openSource");

                    System.out.println("ID: " + id + ", Tool_Name: " + toolName + ", Supported Technologies: "
                            + supportedTech + ", Tool's Owner " + toolOwner + ", Is Tool Opensource " + isOpenSource);
                }
            } else {
                System.out.println("Not Connected...");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static ResultSet readDataWithPreparedStatement(Connection con, String query) {
        ResultSet resultSet = null;
        try {
            if (con != null) {
                PreparedStatement ps = con.prepareStatement(query);
                resultSet = ps.executeQuery();
            } else {
                System.out.println("Not Connected...");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return resultSet;
    }


    public static Map<String, String> getMapFromResultSet(ResultSet resultSet) {
        Map<String, String> row = null;
        try {
            ResultSetMetaData rsmd = resultSet.getMetaData();
            List<String> columns = new ArrayList<String>(rsmd.getColumnCount());
            for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                columns.add(rsmd.getColumnName(i));
            }
            while (resultSet.next()) {
                row = new HashMap<String, String>(columns.size());
                for (String col : columns) {
                    row.put(col, resultSet.getString(col));
                }
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return row;
    }

    public static List<Map<String, String>> getListOfMapFromResultSet(ResultSet resultSet) {
        List<Map<String, String>> data = new ArrayList<Map<String, String>>();
        try {

            ResultSetMetaData rsmd = resultSet.getMetaData();
            List<String> columns = new ArrayList<String>(rsmd.getColumnCount());
            for (int i = 1; i <= rsmd.getColumnCount(); i++) {
                columns.add(rsmd.getColumnName(i));
            }
            while (resultSet.next()) {
                Map<String, String> row = new HashMap<String, String>(columns.size());
                for (String col : columns) {
                    row.put(col, resultSet.getString(col));
                }
                data.add(row);
            }
            System.out.println(data);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return data;
    }

    public static void executeUpdateQuery(Connection con, String query) {
        try {
            if (con != null) {
                Statement statement = con.createStatement();

                // execute the query and get the integer
                int updateValue = statement.executeUpdate(query);
                System.out.println("Updated Query Successfully: " + updateValue);
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void executeDeleteQuery(Connection con, String query) {
        try {
            if (con != null) {
                Statement statement = con.createStatement();

                // execute the delete query
                statement.execute(query);
                System.out.println("Deleted Query Successfully");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public static void executeInsertQuery(Connection con, String query) {
        try {
            if (con != null) {
                Statement statement = con.createStatement();

                // execute the delete query
                statement.execute(query);
                System.out.println("Deleted Query Successfully");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
