package utility;

public interface FrameworkConstants {
	
	public static final String CONFIG_FILE_PATH = "./Test_Configuration/Config.properties";
	
	public static final String POSTRequest_AUTH_DEFAULT_REQUEST = "./Test_Data/PostRequest_Auth.txt";
	
	public static final String DATA_FILE_PATH = "./Test_Data/TestData.xlsx";
	
}
