
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.javafaker.Faker;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given; //import this

import io.restassured.http.ContentType;
import io.restassured.response.Response;
import pojoClasses.BookingDates;
import pojoClasses.BookingDetails;

import pojoClasses.BookingDetailsResponse;
import pojoClasses.BookingIDResponse;
import utility.AllureLogger;
import utility.BaseTest;
import utility.ExcelLib;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class CreateBooking extends BaseTest {
	
	public static String newID = "";
	
	@DataProvider (name="DataFromExcel")
	public Object[][] data() throws Exception {
		ExcelLib xl = new ExcelLib("Booking", this.getClass().getSimpleName());
		return xl.getTestdata();
	}
    
	@Test(dataProvider="DataFromExcel", description="To retrieve the details of the booking IDs") 
	public void createNewBooking(String firstname, 
							  String lastname,
							  String totalprice, 
							  String depositpaid, 
							  String checkin, 
							  String checkout, 
							  String additionalneeds, String dontUseThis
							  ){
		
		AllureLogger.logToAllure("Starting the test to create new details");
		/*******************************************************
		 * Send a POST request to /booking/{id}
		 * and check that the response has HTTP status code 200
		 ******************************************************/
		
		//Sending the POST request for a specific booking details and receiving the response
		AllureLogger.logToAllure("Posting a new booking detail");
		
		BookingDetails bookingDetails = new BookingDetails();
		bookingDetails.setFirstname(firstname);
		bookingDetails.setLastname(lastname);
		bookingDetails.setTotalprice(Integer.parseInt(totalprice));
		bookingDetails.setDepositpaid(Boolean.parseBoolean(depositpaid));
		bookingDetails.setAdditionalneeds(additionalneeds);
		
		BookingDates bookingDates = new BookingDates();
		bookingDates.setCheckin(checkin);
		bookingDates.setCheckout(checkout);
		bookingDetails.setBookingdates(bookingDates);

		Map<String, String> headers = new HashMap<>();


		AllureLogger.logToAllure("Sending the POST request to create new booking");
		Response response = given().
								spec(requestSpec).
								contentType("application/json").
					            body(bookingDetails).log().body().
					        when().
					        	post("/booking");


		//Storing the response in a POJO and retrieving the data
		BookingIDResponse bookingIdResponse = response.as(BookingIDResponse.class);
		System.out.println("BookingID: "+bookingIdResponse.getBookingid());
		System.out.println("Checkin Date: "+bookingIdResponse.getBookingDetailsResponse().getBookingDatesResponse().getCheckin());
		
		//Verify the response code
		AllureLogger.logToAllure("Asserting the response if the status code returned is 200");
		response.then().spec(responseSpec);
		int responseCode = response.getStatusCode();
		System.out.println("Response Code: "+responseCode);
		String responseString = response.prettyPrint();
		System.out.println("Response String :" +responseString);

		//To log the response to report
		logResponseAsString(response);
		
		
		//To get the newly created bookign id
		System.out.println(response.then().extract().path("bookingid").toString());
		newID = response.then().extract().path("bookingid").toString();
		AllureLogger.logToAllure("Retrieved booking id : "+response.then().extract().path("bookingid"));
		
	}

	@Test(description="To retrieve the details of the booking IDs with Static Request and Static Data from properties file")
	public void createNewBookingWithStaticPropertiesData(){

		AllureLogger.logToAllure("Starting the test to create new details with Static Request and Static Data from properties file");
		/*******************************************************
		 * Send a POST request to /booking/{id}
		 * and check that the response has HTTP status code 200
		 ******************************************************/

		//Sending the POST request for a specific booking details and receiving the response
		AllureLogger.logToAllure("Posting a new booking detail with Static Request and Static Data from properties file");

		BookingDetails bookingDetails = new BookingDetails();
		bookingDetails.setFirstname(readConfigurationFile("firstname"));
		bookingDetails.setLastname(readConfigurationFile("lastname"));
		bookingDetails.setTotalprice(Integer.parseInt(readConfigurationFile("totalprice")));
		bookingDetails.setDepositpaid(Boolean.parseBoolean(readConfigurationFile("depositpaid")));
		bookingDetails.setAdditionalneeds(readConfigurationFile("additionalneeds"));

		BookingDates bookingDates = new BookingDates();
		bookingDates.setCheckin(readConfigurationFile("checkin"));
		bookingDates.setCheckout(readConfigurationFile("checkout"));
		bookingDetails.setBookingdates(bookingDates);

		AllureLogger.logToAllure("Sending the POST request to create new booking with Static Request and Static Data from properties file");
		Response response = given().
				spec(requestSpec).
				contentType("application/json").
				body(bookingDetails).log().body().
				when().
				post("/booking");

		//Storing the response in a POJO and retrieving the data
		BookingIDResponse bookingIdResponse = response.as(BookingIDResponse.class);
		System.out.println("BookingID: "+bookingIdResponse.getBookingid());
		System.out.println("Checkin Date: "+bookingIdResponse.getBookingDetailsResponse().getBookingDatesResponse().getCheckin());

		//Verify the response code
		AllureLogger.logToAllure("Asserting the response if the status code returned is 200 with Static Request and Static Data from properties file");
		response.then().spec(responseSpec);
		int responseCode = response.getStatusCode();
		System.out.println("Response Code: "+responseCode);
		String responseString = response.prettyPrint();
		System.out.println("Response String :" +responseString);

		//To log the response to report
		logResponseAsString(response);


		//To get the newly created bookign id
		System.out.println(response.then().extract().path("bookingid").toString());
		newID = response.then().extract().path("bookingid").toString();
		AllureLogger.logToAllure("Retrieved booking id : "+response.then().extract().path("bookingid"));

	}


	@Test(description="To retrieve the details of the booking IDs with Dynamic Request and Static Data from properties file")
	public void createNewBookingWithDynamicRequestAndDynamicData(){

		AllureLogger.logToAllure("Starting the test to create new details with Dynamic Request and Static Data from properties file");
		/*******************************************************
		 * Send a POST request to /booking/{id}
		 * and check that the response has HTTP status code 200
		 ******************************************************/

		//Sending the POST request for a specific booking details and receiving the response
		AllureLogger.logToAllure("Posting a new booking detail with Dynamic Request and Static Data from properties file");

		JSONObject rootObject = new JSONObject();
		rootObject.put("firstname", readConfigurationFile("firstname"));
		rootObject.put("lastname", readConfigurationFile("lastname"));
		rootObject.put("totalprice", readConfigurationFile("totalprice"));
		rootObject.put("depositpaid", readConfigurationFile("depositpaid"));
		rootObject.put("additionalneeds", readConfigurationFile("additionalneeds"));
		rootObject.put("1extraattribute", readConfigurationFile("1extraattribute"));

		JSONObject bookingDates = new JSONObject();
		bookingDates.put("checkin", readConfigurationFile("checkin"));
		bookingDates.put("checkout", readConfigurationFile("checkout"));

		rootObject.put("bookingdates", bookingDates);

		AllureLogger.logToAllure("Sending the POST request to create new booking with Static Request and Static Data from properties file");
		Response response = given().
				spec(requestSpec).
				contentType("application/json").
				body(rootObject.toJSONString()).log().body().
				when().
				post("/booking");

		//Storing the response in a POJO and retrieving the data
		BookingIDResponse bookingIdResponse = response.as(BookingIDResponse.class);
		System.out.println("BookingID: "+bookingIdResponse.getBookingid());
		System.out.println("Checkin Date: "+bookingIdResponse.getBookingDetailsResponse().getBookingDatesResponse().getCheckin());

		//Verify the response code
		AllureLogger.logToAllure("Asserting the response if the status code returned is 200 with Static Request and Static Data from properties file");
		response.then().spec(responseSpec);
		int responseCode = response.getStatusCode();
		System.out.println("Response Code: "+responseCode);
		String responseString = response.prettyPrint();
		System.out.println("Response String :" +responseString);

		//To log the response to report
		logResponseAsString(response);


		//To get the newly created bookign id
		System.out.println(response.then().extract().path("bookingid").toString());
		newID = response.then().extract().path("bookingid").toString();
		AllureLogger.logToAllure("Retrieved booking id : "+response.then().extract().path("bookingid"));

	}

	@Test(description="To retrieve the details of the booking IDs with Dynamic Request and Faker Data")
	public void createNewBookingWithDynamicRequestAndFakerData() throws IOException {

		AllureLogger.logToAllure("Starting the test to create new details with Dynamic Request and Faker Data");
		/*******************************************************
		 * Send a POST request to /booking/{id}
		 * and check that the response has HTTP status code 200
		 ******************************************************/

		//Sending the POST request for a specific booking details and receiving the response
		AllureLogger.logToAllure("Posting a new booking detail with Dynamic Request and Faker Data");

		Faker faker = new Faker();

		JSONObject rootObject = new JSONObject();
		rootObject.put("firstname", faker.name().firstName());
		rootObject.put("lastname", faker.name().lastName());
		rootObject.put("totalprice", faker.number().digits(3));
		rootObject.put("depositpaid", faker.bool().bool());
		rootObject.put("additionalneeds", faker.food().fruit());

		JSONObject bookingDates = new JSONObject();
		bookingDates.put("checkin", readConfigurationFile("checkin"));
		bookingDates.put("checkout", readConfigurationFile("checkout"));

		rootObject.put("bookingdates", bookingDates);

		Map<String, String> headers = new HashMap<>();

		AllureLogger.logToAllure("Sending the POST request to create new booking with Static Request and Static Data from properties file");
//		Response response = given().
//				spec(requestSpec).
//				contentType("application/json").
//				body(rootObject.toJSONString()).log().body().
//				when().
//				post("/booking");
		Response response = postAPI(rootObject.toJSONString(), headers, readConfigurationFile("bookingEndpoint"));

		//Storing the response in a POJO and retrieving the data
		BookingIDResponse bookingIdResponse = response.as(BookingIDResponse.class);

		ObjectMapper objectMapper = new ObjectMapper();
		Map<String, Object> responseMap = objectMapper.readValue(response.prettyPrint(), new TypeReference<Map<String, Object>>() {});
		System.out.println("BookingID: "+bookingIdResponse.getBookingid());
		System.out.println("Checkin Date: "+bookingIdResponse.getBookingDetailsResponse().getBookingDatesResponse().getCheckin());

		//Verify the response code
		AllureLogger.logToAllure("Asserting the response if the status code returned is 200 with Static Request and Static Data from properties file");
		response.then().spec(responseSpec);
		int responseCode = response.getStatusCode();
		System.out.println("Response Code: "+responseCode);
		String responseString = response.prettyPrint();
		System.out.println("Response String :" +responseString);

		//To log the response to report
		logResponseAsString(response);


		//To get the newly created bookign id
		System.out.println(response.then().extract().path("bookingid").toString());
		newID = response.then().extract().path("bookingid").toString();
		AllureLogger.logToAllure("Retrieved booking id : "+response.then().extract().path("bookingid"));

	}
}
